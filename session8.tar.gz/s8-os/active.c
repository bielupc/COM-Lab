#include <stdio.h>
#include <stdlib.h>

int main() {
    while (1) {
        // Res
    }
    return 0;
}
