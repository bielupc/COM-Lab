#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    
    double a = atof(argv[1]);
    double b = atof(argv[3]);
    char operator = argv[2][0];
    double result;
    
    if (operator == '+') {
        result = a + b;
        printf("%f + %f = %f\n", a, b, result);
    } else if (operator == '-') {
        result = a - b;
        printf("%f - %f = %f\n", a, b, result);
    } else if (operator == '*') {
        result = a * b;
        printf("%f * %f = %f\n", a, b, result);
    } else if (operator == '/') {
        if (b == 0) {
            printf("Error: Division by zero\n");
        } else {
            result = a / b;
            printf("%f / %f = %f\n", a, b, result);
        }
    } else {
        printf("Error: Invalid operator\n");
    }
    return 0;
}



