#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>

int main (int argc, char **argv)
{
  int i, f, lenR;
  int N = 1000000;
  int buf[N];

  f = open("./output.dat", O_RDONLY);
  lenR = read(f, buf, N);
  while (lenR > 0){
      write (1, buf, N);
      lenR = read(f, buf, N);
  }
}
