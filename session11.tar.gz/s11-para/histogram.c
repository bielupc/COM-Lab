#include <stdio.h>
#include <string.h>
#include <omp.h>
#include <unistd.h>
#include <sys/time.h>

double now()
{
   struct timeval tv;
   int res = gettimeofday(&tv, NULL);
   if (res < 0) perror("gettimeofday");
   double t = (double) tv.tv_sec + (double) tv.tv_usec / 1000000.0;
   return t;
}

int main(int argc, char **argv){
	// IMPORTANT VARIABLES TO BE MANAGED FOR THE DEVELOPMENT
	// Feel free to modify any variable declaration placement if you consider it is necessary
	int totalCount = 0; // Number of total chars
	int localCount = 0; // Number of chars read per thread
	int histo[128];    // Histogram of chars
	char c; // Char read
	
	int i = 0; // iterator
	int len = 0;
	char buf[256];
	double t0; // start time
	double t1; // end time
	
	// Initialize histogram
	for (i = 0; i < 128; i++)
		histo[i] = 0;
		
	// Take start time
	t0 = now();

	// START OF THE CODE TO BE PARALLELIZED
	#pragma omp parallel private(c, localCount) shared(totalCount, histo)
	{
		localCount = 0;

		#pragma omp for
		for (i = 0; i < 128; i++)
			histo[i] = 0;

			// En alguns casos, ens donava un caràcter menys pel Char 97, afegint els atomics sembla solucionar el problema.

		#pragma omp while
		while (read(0, &c, 1) > 0) {
			#pragma omp atomic
			totalCount++;
			
			#pragma omp atomic
			histo[c]++;
			
			localCount++;
		}

		#pragma omp critical
		{
			len = sprintf(buf, "Thread %d: processed %d characters\n", omp_get_thread_num(), localCount);
			write(2, buf, len);
		}
	}
	// END OF THE CODE TO BE PARALLELIZED

	// Take "end" time
	t1 = now();

	// Print histogram results
	localCount = 0;
	for (i = 0; i < 128; i++){
		len = sprintf(buf, "Char %d: there are %d\n", i, histo[i]);
		write(2, buf, len);
		localCount += histo[i];
	}
	
	// Show processing time
	printf("Total %d vs %d\nTime: %lf s\n", totalCount, localCount,  t1 - t0);

	return 0;
}